@interface @@CLASSPREFIX@@RootViewController : UITableViewController

@end
